# ⑯ 独立検証 最新版（HEAD 1da3238d）の受け渡しパッケージ

- ブランチ: `claude/dreamy-ramanujan-ijj8qj`（GitHub には未 push）
- HEAD: `1da3238d03fcb50b3da168fb3618fd4d694e2e05`
- tree: `f3071569b2a155011ea6b22a8fd81df43418919b`
- bundle の前提 commit: `921429322d5aecd1a3df0dd8d82c405c87dd985a`（GitHub `r0ze998/wylls` の `main`。`4cd901de` も含む）
- 中身: ⑯の 6 コミット（`2fbc6a21` `fc8e8ec3` `413dd23b` `c7719875` `115f43a9` `1da3238d`）。本体コードの変更はなく、試験・文書・パッチ・ログ・スクリプトだけ

## 復元

```sh
git clone https://github.com/r0ze998/wylls.git && cd wylls     # 既存の clone なら git fetch origin main
git bundle verify /path/to/verify16-1da3238d.bundle             # 「The bundle requires this ref: 92142932…」で ok
git fetch /path/to/verify16-1da3238d.bundle claude/dreamy-ramanujan-ijj8qj:refs/heads/verify16-1da3238d
git checkout verify16-1da3238d
git rev-parse HEAD 'HEAD^{tree}'   # 1da3238d03fc… と f3071569b2a1… になること
```

## 同梱物

| パス | 中身 |
|---|---|
| `verify16-1da3238d.bundle` | 上記 6 コミット |
| `verify16/` | HEAD 時点の `verification/16-independent/`（REPORT・INVENTORY・INVARIANTS・README・CHECKLIST-INTAKE、`patches/` P1〜P12、受け入れ・パッケージ用スクリプト）。`inbox/` は除いた |
| `logs-not-in-commit/` | 試験の実行ログ 20 本。repo の `.gitignore` の `*.log` 規則で**コミットにも bundle にも入っていない**。作業ディレクトリ `verification/16-independent/logs/` から複製した補助ファイルで、bundle の復元では得られない |
| `tests/` | ⑯の再現試験 11 ファイル（repo 内と同じパスで配置） |
| `HEAD.sha` `HEAD.tree` `PREREQUISITE.sha` | 照合用 |
| `SHA256SUMS` | このパッケージ内の全ファイル |

P8 は単独のパッチファイルではなく、P7（`src/frontier/routes/prize.mjs`）の最後のハンクに含まれる（`verify16/patches/P8-claim-amount-unknown-not-zero.NOTE.md`）。P11・P12 は④の `preserve/ws04-a967f5f1` の `workstreams/04-execution/patches/from16/` にも同じ sha256 で入っている。

試験の実行手順は `verify16/README.ja.md`、修正候補の適用と検証結果は `verify16/patches/README.ja.md`、結果の全体は `verify16/REPORT.ja.md`。
